module.exports = {

    getdata: function (db, strSQL, data, callback) {
        db.query(strSQL, function (err, rows) {
            if (err) {
                console.log(err);
            }
            else {
                data.push(rows);
                callback(data);
            }
        });
    },

    getdata: function (db, strSQL, para, data, callback) {
        db.query(strSQL, para, function (err, rows) {
            if (err) {
                console.log(err);
            }
            else {
                data.push(rows);
                callback(data);
            }
        });
    },

    dataupdate: function (db, strSQL, para, callback) {
        db.query(strSQL, para, function (err, rows) {
            if (err) {
                console.log(err);
            }
            else {
                callback(rows);
            }
        });
    },

    getuser: function (db, username, data, callback) {
        var strSQL = "SELECT * FROM USERS WHERE USERNAME=?";
        var para = [username];
        this.getdata(db, strSQL, para, data, callback);
    },

    getpages: function (db, groupnode, data, callback) {
        var strSQL = "SELECT * FROM PAGES WHERE GROUPNODE=? ORDER BY NO";
        var para = [groupnode];
        this.getdata(db, strSQL, para, data, callback);
    }

};
