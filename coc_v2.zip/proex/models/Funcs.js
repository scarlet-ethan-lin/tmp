module.exports = {

    getdata: function (db, strSQL, data, callback) {
        db.query(strSQL, function (err, rows) {
            if (err) {
                console.log(err);
            }
            else {
                data.push(rows);
                callback(data);
            }
        });
    },

    getdata: function (db, strSQL, para, data, callback) {
        db.query(strSQL, para, function (err, rows) {
            if (err) {
                console.log(err);
            }
            else {
                data.push(rows);
                callback(data);
            }
        });
    },

    dataupdate: function (db, strSQL, para, callback) {
        db.query(strSQL, para, function (err, rows) {
            if (err) {
                console.log(err);
            }
            else {
                callback(rows);
            }
        });
    },

    /* 取得正在生產資料 */
    getmaking: function (db, today, data, callback) {
        var strSQL = "SELECT cases.ID, cases.CasePrimary, cases.CarType, cases.CaseName, cases.CycleTime, dp.Plan, dp.Made, cases.Remarks" +
            " FROM dateplan AS dp LEFT JOIN cases ON dp.caseid=cases.id" +
            " WHERE status=1 AND plandate=?";
        var para = today;
        this.getdata(db, strSQL, para, data, callback);
    },


    /* 取得今日生產計劃 */
    getdateplan: function (db, today, data, callback) {
        var strSQL = "SELECT dp.SN, cases.CasePrimary, cases.CaseSecondary, cases.CaseSN, cases.CarType, cases.CaseName, cases.CycleTime, dp.Plan, dp.Made, cases.Remarks" +
            " FROM dateplan AS dp LEFT JOIN cases ON dp.caseid=cases.id WHERE plandate=? ORDER BY dp.SN";
        var para = today;
        this.getdata(db, strSQL, para, data, callback);
    },


    /* 更新實際產量 */
    updatemade: function (db, made, today, callback) {
        var strSQL = "UPDATE coc.dateplan SET Made=? WHERE plandate=? AND status=1";
        var para = [made, today];
        this.dataupdate(db, strSQL, para, callback);
    },


    /* 取得模具資料 */
    getcasesbyid: function (db, caseid, data, callback) {
        var strSQL = "SELECT * FROM cases WHERE ID=?";
        var para = caseid;
        this.getdata(db, strSQL, para, data, callback);
    },

    /* 取得模具資料 */
    getcasesbypri: function (db, primary, data, callback) {
        var strSQL = "SELECT * FROM cases WHERE caseprimary=?";
        var para = primary;
        this.getdata(db, strSQL, para, data, callback);
    },

    /* 取得檢查要領 */
    getcheckspec: function (db, primary, data, callback) {
        var strSQL = "SELECT * FROM v_checkspec WHERE caseprimary=?";
        var para = primary;
        this.getdata(db, strSQL, para, data, callback);
    },

    /* 取得不良履歷 */
    getnghistory: function (db, primary, data, callback) {
        var strSQL = "SELECT * FROM v_nghistory WHERE caseprimary=?";
        var para = primary;
        this.getdata(db, strSQL, para, data, callback);
    },

    /* 取得加工站資料 */
    getstationsbyid: function (db, caseid, stationno, data, callback) {
        var strSQL = "SELECT * FROM stations WHERE caseid=? AND stationno=?";
        var para = [caseid, stationno];
        this.getdata(db, strSQL, para, data, callback);
    },

    /* 取得加工站資料(含模具資料) */
    getstnlldatabyid: function (db, caseid, stationno, data, callback) {
        var strSQL = "SELECT * FROM v_stations WHERE id=? AND stationno=?";
        var para = [caseid, stationno];
        this.getdata(db, strSQL, para, data, callback);
    },

    /* 取得加工站資料(含模具資料) */
    getstnlldatabypri: function (db, primary, stationno, data, callback) {
        var strSQL = "SELECT * FROM v_stations WHERE caseprimary=? AND stationno=?";
        var para = [primary, stationno];
        this.getdata(db, strSQL, para, data, callback);
    }


};
