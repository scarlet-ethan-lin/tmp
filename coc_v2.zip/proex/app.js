var express = require('express');
var path = require('path');
var favicon = require('static-favicon');
var logger = require('morgan');
var cookieParser = require('cookie-parser');
var bodyParser = require('body-parser');
var session = require('express-session');
var dateFormat = require('dateformat');
var io = require('socket.io');
var mysql = require('mysql');


//Routes
var testpage = require('./routes/testpage');
var testpagews = require('./routes/testpagews');

var index = require('./routes/index');
var front = require('./routes/frontend');
var dateplan = require('./routes/dateplan');
var checkspec = require('./routes/checkspec');
var nghistory = require('./routes/nghistory');
var robota1 = require('./routes/robota1');
var robota2 = require('./routes/robota2');
var robota3 = require('./routes/robota3');
var robota4 = require('./routes/robota4');
var robota5 = require('./routes/robota5');
var login = require('./routes/login');
var addplan = require('./routes/addplan');
var addnghistory = require('./routes/addnghistory');
var editplan = require('./routes/editplan');
var addngpoint = require('./routes/addngpoint');
var planreport = require('./routes/planreport');
var editcases = require('./routes/editcases');
var editresttime = require('./routes/editresttime');


//Functions
var funcs = require('./models/Funcs.js');
var userfuncs = require('./models/UserFuncs.js');


var app = express();


// DataBase 
var con = mysql.createConnection({
    host: '13.114.97.101',
    user: 'ivy',
    password: 'scarlet123',
    database: 'coc'
});

con.connect(function (err) {
    if (err) {
        console.log('connecting error');
        return;
    }
    console.log('connecting success');
});

// view engine setup
app.set('views', path.join(__dirname, 'views'));
app.set('view engine', 'ejs');

app.use(favicon());
app.use(logger('dev'));
app.use(bodyParser.json());
app.use(bodyParser.urlencoded());
app.use(cookieParser());
app.use(express.static(path.join(__dirname, 'public')));


// db state
app.use(function (req, res, next) {
    req.con = con;
    next();
});

// Set Functions
app.use(function (req, res, next) {
    req.funcs = funcs;
    req.userfuncs = userfuncs;
    next();
});

app.use('/testpage', testpage);
app.use('/testpagews', testpagews);

app.use('/index', index);
app.use('/dateplan', dateplan);
app.use('/checkspec', checkspec);
app.use('/nghistory', nghistory);
app.use('/frontend', front);
app.use('/robota1', robota1);
app.use('/robota2', robota2);
app.use('/robota3', robota3);
app.use('/robota4', robota4);
app.use('/robota5', robota5);
app.use('/login', login);
app.use('/addplan', addplan);
app.use('/addnghistory', addnghistory);
app.use('/editplan', editplan);
app.use('/addngpoint', addngpoint);
app.use('/planreport', planreport);
app.use('/editcases', editcases);
app.use('/editresttime', editresttime);


/// catch 404 and forwarding to error handler
app.use(function (req, res, next) {
    var err = new Error('Not Found');
    err.status = 404;
    next(err);
});

/// error handlers

// development error handler
// will print stacktrace
if (app.get('env') === 'development') {
    app.use(function (err, req, res, next) {
        res.status(err.status || 500);
        res.render('error', {
            message: err.message,
            error: err
        });
    });
}

// production error handler
// no stacktraces leaked to user
app.use(function (err, req, res, next) {
    res.status(err.status || 500);
    res.render('error', {
        message: err.message,
        error: {}
    });
});

//MQTT
var mqtt = require('mqtt');
var opt = {
    port: 1883,
    clientId: 'cocmqtt',
    username: 'ivy',
    password: 'scarlet123'
};
//var client  = mqtt.connect('mqtt://test.mosquitto.org',opt);
var client = mqtt.connect('mqtt://mqtt.scarlet.com.tw', opt);

// Set Functions
app.use(function (req, res, next) {
    req.client = client;
    next();
});


//default layout is layout.ejs, display it.
app.set('view options', { layout: false });

var server = app.listen(3000, function () {
    console.log('Listening on port 3000');
});



//socket
var sio = io.listen(server);

client.on('connect', function () {
    console.log('已連接至MQTT伺服器:' + client.options.host);
    client.subscribe('#');
});

sio.on('connection', function (socket) {
    client.on('message', function (topic, msg) {
        //console.log('收到 ' + topic + ' 主題，訊息：' + msg.toString());
        var mqttmsg = JSON.parse(msg);        
        var mqttdata = mqttmsg[0].data;
        

        //ascii to string
        var hex = mqttdata.toString();
        var mqttstr = "";
        for (var i = 0; i < hex.length; i += 2) {
            mqttstr += String.fromCharCode(parseInt(hex.substr(i, 2), 16));
        }
        mqttmsg.Made=mqttstr;
        console.log(mqttstr);

        var now = new Date();
        var today = dateFormat(now, 'yyyy/mm/dd');
        var plandata = [], making = [];


        //更新實際產量
        funcs.updatemade(con, mqttmsg.Made, today, function (result) {
            //取得今日生產計劃
            funcs.getdateplan(con, today, plandata, function (result) {
                //取得正在生產模具
                funcs.getmaking(con, today, making, function (result) {

                    //dateplan
                    var now = new Date();
                    var today = dateFormat(now, 'yyyy/mm/dd');
                    for (var i = plandata[0].length; i < 10; i++) {
                        plandata[0].push({ "SN": (i + 1).toString(), "CasePrimary": "", "CaseSecondary": "", "CaseSN": "", "CarType": "", "CaseName": "", "CycleTime": "", "Plan": "", "Made": "", "Remarks": "" });
                    }
                    socket.emit('dateplan', { "data": plandata, "making": making, "ChangeTime": "", "Now": today, "Made": mqttmsg.Made });


                    //checkspec        
                    var spec = [], cases = [];
                    var specimg = "";

                    var primary = making[0][0].CasePrimary;
                    funcs.getcheckspec(con, primary, spec, function (result) {
                        funcs.getcasesbypri(con, primary, cases, function (result) {
                            for (var i = spec[0].length; i < 10; i++) {
                                spec[0].push({ "ID": "", "CASEPRIMARY": "", "IMGNAME": "", "ITEMID": "", "CHECKITEM": "" });
                            }
                            for (var i = cases[0].length; i < 5; i++) {
                                cases[0].push({ "CaseSN": "", "Holes": "" });
                            }
                            if (spec[0][0].IMGNAME.length > 0) {
                                specimg = "images/" + spec[0][0].IMGNAME;
                            }

                            socket.emit('checkspec', { "making": making, "ChangeTime": "", "Now": today, "CheckSpecImg": "", "SpecImg": specimg, "spec": spec, "cases": cases });
                        });
                    });


                    //nghistory             
                    var nglist = [];
                    var NGImage = "";

                    var primary = making[0][0].CasePrimary;
                    funcs.getnghistory(con, primary, nglist, function (result) {
                        for (var i = nglist[0].length; i < 24; i++) {
                            nglist[0].push({ "NGSN": "", "NGPoint": "", "ImgName": "" });
                        }
                        if (nglist[0][0].ImgName.length > 0) {
                            NGImage = "images/" + nglist[0][0].ImgName;
                        }

                        socket.emit('nghistory', { "making": making, "ChangeTime": "", "Now": today, "CheckSpecImg": "", "NGlist": nglist, "NGImg": NGImage });
                    });


                    //frontend                                                                           
                    for (var i = plandata[0].length; i < 10; i++) {
                        plandata[0].push({ "SN": (i + 1).toString(), "CasePrimary": "", "CaseSecondary": "", "CaseSN": "", "CarType": "", "CaseName": "", "CycleTime": "", "Plan": "", "Made": "", "Remarks": "" });
                    }
                    socket.emit('frontend', { "data": plandata, "making": making, "ChangeTime": "", "Now": today, "Made": mqttmsg.Made });


                    //robota1
                    var stna1 = [];
                    var caseid = making[0][0].ID;
                    funcs.getstationsbyid(con, caseid, "A1", stna1, function (result) {
                        if (stna1[0].length == 0) {
                            stna1[0].push({ "ID": "", "CaseID": "", "Station": "", "SPM": "", "MoldH": "", "ProdessH": "", "MatH": "", "MatP": "", "BalanceP": "" });
                        }
                        socket.emit('robota1', { "making": making, "stn": stna1 });
                    });


                    //robota2
                    var stna2 = [];
                    funcs.getstationsbyid(con, caseid, "A2", stna2, function (result) {
                        if (stna2[0].length == 0) {
                            stna2[0].push({ "ID": "", "CaseID": "", "Station": "", "SPM": "", "MoldH": "", "ProdessH": "", "MatH": "", "MatP": "", "BalanceP": "" });
                        }
                        socket.emit('robota2', { "making": making, "stn": stna2 });
                    });


                    //robota3
                    var stna3 = [];
                    funcs.getstationsbyid(con, caseid, "A3", stna3, function (result) {
                        if (stna3[0].length == 0) {
                            stna3[0].push({ "ID": "", "CaseID": "", "Station": "", "SPM": "", "MoldH": "", "ProdessH": "", "MatH": "", "MatP": "", "BalanceP": "" });
                        }
                        socket.emit('robota3', { "making": making, "stn": stna3 });
                    });


                    //robota4
                    var stna4 = [];
                    funcs.getstationsbyid(con, caseid, "A4", stna4, function (result) {
                        if (stna4[0].length == 0) {
                            stna4[0].push({ "ID": "", "CaseID": "", "Station": "", "SPM": "", "MoldH": "", "ProdessH": "", "MatH": "", "MatP": "", "BalanceP": "" });
                        }
                        socket.emit('robota4', { "making": making, "stn": stna4 });
                    });


                    //robota5
                    var stna5 = [];
                    funcs.getstationsbyid(con, caseid, "A5", stna5, function (result) {
                        if (stna5[0].length == 0) {
                            stna5[0].push({ "ID": "", "CaseID": "", "Station": "", "SPM": "", "MoldH": "", "ProdessH": "", "MatH": "", "MatP": "", "BalanceP": "" });
                        }
                        socket.emit('robota5', { "making": making, "stn": stna5 });
                    });

                });
            });



            //         switch(topic)
            //        {        
            //         case 'scarlet/mqtt/dateplan':                      

            //         break;

            //         case 'scarlet/mqtt/checkspec':           

            //         break;

            //         case 'scarlet/mqtt/nghistory':           

            //         break;

            //         case 'scarlet/mqtt/frontend':

            //         break;

            //         case 'scarlet/mqtt/robota1':

            //         break; 

            //         case 'scarlet/mqtt/robota2':

            //         break; 

            //         case 'scarlet/mqtt/robota3':

            //         break; 

            //         case 'scarlet/mqtt/robota4':

            //         break; 

            //         case 'scarlet/mqtt/robota5':

            //         break; 
            //        }
        });
    });
});


module.exports = app;
